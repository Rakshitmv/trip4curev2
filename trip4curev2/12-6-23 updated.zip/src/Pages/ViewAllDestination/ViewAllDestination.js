import React from 'react'

const ViewAllDestination = () => {
  return (
    <div>ViewAllDestination</div>
  )
}

export default ViewAllDestination