import React from 'react'

const CosemticSurgery = () => {
  return (
    <div>CosemticSurgery</div>
  )
}

export default CosemticSurgery