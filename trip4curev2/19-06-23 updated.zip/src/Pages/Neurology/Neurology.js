import React from 'react'

export const Neurology = () => {
  return (
    <div>Neurology</div>
  )
}
