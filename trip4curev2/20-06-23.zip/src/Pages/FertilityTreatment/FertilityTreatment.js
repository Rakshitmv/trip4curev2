import React from 'react'

const FertilityTreatment = () => {
  return (
    <div>FertilityTreatment</div>
  )
}

export default FertilityTreatment