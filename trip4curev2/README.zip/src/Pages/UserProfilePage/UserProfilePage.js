import React from 'react'
import { Col, Container, Form, Row, Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import Header from '../../Components/Header/Header';
import Footer from '../../Components/Footer/Footer';

const UserProfilePage = () => {
    return (
        <>
            <Header />
            <div>UserProfilePage</div>
            <Footer />
        </>
    
  )
}

export default UserProfilePage