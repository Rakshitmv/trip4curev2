import React from 'react'
import '../ViewSpeciality/ViewSpeciality.css'

const ViewSpeciality = () => {
  return (
    
      <>
          <div></div>
      </>
  )
}

export default ViewSpeciality