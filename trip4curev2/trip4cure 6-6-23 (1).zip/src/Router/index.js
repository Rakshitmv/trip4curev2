import { createBrowserRouter } from "react-router-dom";
import Homepage from "../Pages/Homepage/Homepage";
import ForgotPassword from "../Pages/ForgotPassword/ForgotPassword";
import SignIn from "../Pages/SignIn/SignIn";
import SignUp from "../Pages/SignUp/SignUp";
import NewPassword from "../Pages/NewPassword/NewPassword";
import VerifyAccount from "../Pages/VerifyAccount/VerifyAccount";
import HospitalSignIn from "../Pages/HospitalSignIn/HospitalSignIn";
import HospitalSignUp from "../Pages/HospitalSignUp/HospitalSignUp";
import ContactUS from "../Pages/ContactUS/ContactUS";
import ResetPassword from "../Pages/ResetPassword/ResetPassword";
import VerifyOtp from "../Pages/VerifyOtp/VerifyOtp";


const router = createBrowserRouter([
    {
      path: "/",
      element: <Homepage />
    },
    {
      path: "/user-sign-in",
      element: <SignIn />
    },
    {
      path: "/hospital-sign-in",
      element: <HospitalSignIn />
    },
    {
      path: "/sign-up",
      element: <SignUp />
    },
    {
      path: "/hospital-sign-up",
      element: <HospitalSignUp />
  },
    {
      path: "/contact-us",
      element: <ContactUS />
  },
    {
      path: "/forgot-password",
      element: <ForgotPassword /> 
    },
    {
      path: "/new-password",
      element: <NewPassword /> 
    },
    {
      path: "/reset-password",
      element: <ResetPassword /> 
    },
    {
      path: "/verify-account/:name",
      element: <VerifyAccount /> 
    },
    {
      path: "/verify-otp",
      element: <VerifyOtp /> 
    }
    ],
     { basename: '/trip4cureV2' }
    );


  export default router;